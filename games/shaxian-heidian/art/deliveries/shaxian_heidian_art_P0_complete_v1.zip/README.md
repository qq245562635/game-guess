# 沙县黑店 美术资源包 — P0 完整版

生成日期：2026-10-17

## 内容

本包已补齐需求文档中的 **P0 全部 39 张资源**：

- tiles：5 张
- facilities：7 张
- characters：12 张（6 个角色 × 2 帧）
- items：1 张
- ui：14 张

合计：**39 张**。

## 目录

```text
games/shaxian-heidian/art/
├─ tiles/
├─ facilities/
├─ characters/
├─ items/
└─ ui/
```

## 已完成清单

- `tiles/floor_hall.png`
- `tiles/floor_kitchen.png`
- `tiles/door.png`
- `tiles/street.png`
- `tiles/wall.png`
- `facilities/stove.png`
- `facilities/steamer.png`
- `facilities/pot.png`
- `facilities/table.png`
- `facilities/plant.png`
- `facilities/banner.png`
- `facilities/camera.png`
- `characters/chef_0.png`
- `characters/chef_1.png`
- `characters/worker_0.png`
- `characters/worker_1.png`
- `characters/neighbor_0.png`
- `characters/neighbor_1.png`
- `characters/influencer_0.png`
- `characters/influencer_1.png`
- `characters/foodie_0.png`
- `characters/foodie_1.png`
- `characters/rich_0.png`
- `characters/rich_1.png`
- `items/bowl.png`
- `ui/icon_cash.png`
- `ui/icon_clock.png`
- `ui/icon_rent.png`
- `ui/icon_black.png`
- `ui/icon_rep.png`
- `ui/icon_favor.png`
- `ui/icon_task.png`
- `ui/tab_price.png`
- `ui/tab_build.png`
- `ui/tab_staff.png`
- `ui/btn_ad.png`
- `ui/btn_speed.png`
- `ui/icon_report.png`
- `ui/icon_inspect.png`

## 规格说明

- 场景 / 角色 / 道具：最终文件按 16×16 逻辑像素格制作并以 nearest-neighbor 放大到 64×64；`wall.png` 为 64×16。
- UI：12×12 逻辑像素格放大到 48×48。
- 设施、角色、道具、UI：PNG 透明背景；地块类为不透明。
- 主描边：深棕 `#2a1d16`；光源默认左上。
- `worker_0/1` 沿用首批定调资源；其余角色按同一套 Q 版像素方向补齐。
- 角色 `_0` 为站立帧，`_1` 为迈步帧。
- UI 图标针对深紫 `#211a28` 背景做了高对比处理。

## 说明与注意

这是一版 **可直接进工程试用的 P0 完整包**。其中首批 10 张保留了之前确定的美术方向，并统一做了像素格化；后补资源来自同套风格生成与像素化处理。由于生成式美术在角色二帧的一致性上仍可能存在细小差异，建议实际跑起来后重点检查：

1. `chef / neighbor / influencer / foodie / rich` 的 `_0/_1` 动画切换是否跳形。
2. `wall.png` 横向平铺接缝。
3. `plant/banner/camera/bowl` 在手机 64px/32px 显示时的辨识度。
4. 14 个 UI 图标在深紫界面上的对比度与统一感。

## 后续

P1 / P2 尚未制作。下一阶段应继续：

- P1：`shop_sign`、`counter`、`booth`、`takeout`、主角/检查员/房东角色、4 道菜、4 个表情、7 张剧情立绘。
- P2：`neon_sign`、`lucky_cat`、`altar`、`app_icon`、`share`、`loading_bg`。
